const express = require('express');
const router = express.Router();
// const todoService = require('../services/todoService');
const {getTodosByList, createTodo, getTodoById, updateTodo, deleteTodo} = require('../services/todoController');
const { protect } = require('../middleware/auth');

router.get('/', protect, getTodosByList);
router.post('/', createTodo);

router.route('/:id')
    .get(getTodoById)
    .put(updateTodo)
    .delete(deleteTodo);

module.exports = router;